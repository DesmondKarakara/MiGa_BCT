import { Component, Input } from '@angular/core';

export interface GameObjective {
  title: string;
  description: string;
  winCondition: string;
  failCondition: string;
  controls: { key: string; action: string }[];
  tips: string[];
  scoring?: string[];
}

@Component({
  selector: 'app-instruction-manual',
  template: `
    <div class="instruction-manual" *ngIf="showInstructions">
      <div class="manual-overlay" (click)="closeManual()"></div>
      <div class="manual-content">
        <div class="manual-header">
          <h2>📖 {{ gameObjective.title }} - Instructions</h2>
          <button class="close-btn" (click)="closeManual()">✖</button>
        </div>
        
        <div class="manual-body">
          <section class="objective-section">
            <h3>🎯 Objective</h3>
            <p>{{ gameObjective.description }}</p>
            
            <div class="conditions">
              <div class="win-condition">
                <h4>🏆 Win Condition</h4>
                <p>{{ gameObjective.winCondition }}</p>
              </div>
              <div class="fail-condition" *ngIf="gameObjective.failCondition">
                <h4>❌ Fail Condition</h4>
                <p>{{ gameObjective.failCondition }}</p>
              </div>
            </div>
          </section>

          <section class="controls-section" *ngIf="gameObjective.controls.length > 0">
            <h3>🎮 Controls</h3>
            <div class="controls-grid">
              <div class="control-item" *ngFor="let control of gameObjective.controls">
                <kbd>{{ control.key }}</kbd>
                <span>{{ control.action }}</span>
              </div>
            </div>
          </section>

          <section class="scoring-section" *ngIf="gameObjective.scoring">
            <h3>📊 Scoring</h3>
            <ul>
              <li *ngFor="let score of gameObjective.scoring">{{ score }}</li>
            </ul>
          </section>

          <section class="tips-section" *ngIf="gameObjective.tips.length > 0">
            <h3>💡 Tips</h3>
            <ul>
              <li *ngFor="let tip of gameObjective.tips">{{ tip }}</li>
            </ul>
          </section>
        </div>

        <div class="manual-footer">
          <button class="start-btn" (click)="startGame()">🚀 Start Game</button>
          <button class="close-btn-alt" (click)="closeManual()">Close Manual</button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .instruction-manual {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      z-index: 1000;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .manual-overlay {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.7);
      backdrop-filter: blur(5px);
    }

    .manual-content {
      position: relative;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      border-radius: 20px;
      max-width: 600px;
      max-height: 80vh;
      overflow-y: auto;
      box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
      color: white;
    }

    .manual-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 20px 30px;
      border-bottom: 1px solid rgba(255, 255, 255, 0.2);
    }

    .manual-header h2 {
      margin: 0;
      font-size: 1.5rem;
    }

    .close-btn {
      background: rgba(255, 255, 255, 0.2);
      border: none;
      color: white;
      width: 30px;
      height: 30px;
      border-radius: 50%;
      cursor: pointer;
      font-size: 14px;
    }

    .close-btn:hover {
      background: rgba(255, 255, 255, 0.3);
    }

    .manual-body {
      padding: 30px;
    }

    .manual-body section {
      margin-bottom: 25px;
    }

    .manual-body h3 {
      margin: 0 0 15px 0;
      font-size: 1.2rem;
      color: #ffd700;
    }

    .manual-body h4 {
      margin: 10px 0 5px 0;
      font-size: 1rem;
    }

    .conditions {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 20px;
      margin-top: 15px;
    }

    .win-condition, .fail-condition {
      background: rgba(255, 255, 255, 0.1);
      padding: 15px;
      border-radius: 10px;
    }

    .win-condition {
      border-left: 4px solid #4caf50;
    }

    .fail-condition {
      border-left: 4px solid #f44336;
    }

    .controls-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 10px;
    }

    .control-item {
      display: flex;
      align-items: center;
      gap: 10px;
      padding: 8px 12px;
      background: rgba(255, 255, 255, 0.1);
      border-radius: 8px;
    }

    .control-item kbd {
      background: rgba(0, 0, 0, 0.3);
      padding: 4px 8px;
      border-radius: 4px;
      font-family: monospace;
      font-weight: bold;
      min-width: 30px;
      text-align: center;
    }

    .scoring-details p {
      margin: 8px 0;
      padding: 8px 12px;
      background: rgba(255, 255, 255, 0.1);
      border-radius: 6px;
    }

    .tips-section ul {
      list-style: none;
      padding: 0;
    }

    .tips-section li {
      padding: 8px 12px;
      margin: 8px 0;
      background: rgba(255, 255, 255, 0.1);
      border-radius: 6px;
      border-left: 3px solid #ffd700;
    }

    .manual-footer {
      padding: 20px 30px;
      border-top: 1px solid rgba(255, 255, 255, 0.2);
      display: flex;
      gap: 15px;
      justify-content: center;
    }

    .start-btn, .close-btn-alt {
      padding: 12px 24px;
      border: none;
      border-radius: 25px;
      cursor: pointer;
      font-weight: bold;
      transition: all 0.3s ease;
    }

    .start-btn {
      background: linear-gradient(45deg, #4caf50, #45a049);
      color: white;
    }

    .start-btn:hover {
      transform: translateY(-2px);
      box-shadow: 0 5px 15px rgba(76, 175, 80, 0.4);
    }

    .close-btn-alt {
      background: rgba(255, 255, 255, 0.2);
      color: white;
    }

    .close-btn-alt:hover {
      background: rgba(255, 255, 255, 0.3);
    }

    @media (max-width: 768px) {
      .manual-content {
        max-width: 95%;
        margin: 10px;
      }

      .conditions {
        grid-template-columns: 1fr;
      }

      .controls-grid {
        grid-template-columns: 1fr;
      }

      .manual-footer {
        flex-direction: column;
      }
    }
  `]
})
export class InstructionManualComponent {
  @Input() gameObjective!: GameObjective;
  @Input() showInstructions = false;

  closeManual() {
    this.showInstructions = false;
  }

  startGame() {
    this.showInstructions = false;
    // Emit event to parent component to start the game
    // This will be handled by each individual game component
  }
}