import { Component } from '@angular/core';

@Component({
  selector: 'app-main-menu',
  templateUrl: './main-menu.component.html',
  styleUrl: './main-menu.component.css'
})
export class MainMenuComponent {
  //photo_copy={
    //imageUrl: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQeYW9YU-f7YyZhdKRJOKTNUbg5bZu6wPdymg&s' 
  //}
  
    
}
