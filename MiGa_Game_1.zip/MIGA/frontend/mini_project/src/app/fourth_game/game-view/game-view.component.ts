import { Component } from '@angular/core';

@Component({
  selector: 'app-game-view',
  templateUrl: './game-view.component.html',
  styleUrl: './game-view.component.css'
})
export class GameViewComponent {
gameOver: any;
speed: any;
confirmReady() {
throw new Error('Method not implemented.');
}
  message: string = 'Click "Start" to begin!';
  gameState: 'idle' | 'countdown' | 'waiting' | 'ready' | 'clicked' | 'done' = 'idle';
  startTime: number = 0;
  endTime: number = 0;
  reactionTime: number = 0;
  fastestTime: number | null = null;
  showPrompt: boolean | undefined;

  startGame() {
    this.reset();
    this.gameState = 'countdown';
    this.message = 'Get Ready...';

    // Show visible 3-second countdown
    setTimeout(() => {
      this.gameState = 'waiting';
      this.message = 'Wait for green...';

      // Random delay from 100ms to 5000ms
      const delay = 100 + Math.random() * 4900;
      setTimeout(() => {
        if (this.gameState === 'waiting') {
          this.gameState = 'ready';
          this.message = 'CLICK NOW!';
          this.startTime = performance.now();
        }
      }, delay);
    }, 3000);
  }

  onScreenClick() {
    if (this.gameState === 'waiting') {
      this.message = 'Too Soon! Wait for the signal.';
      this.gameState = 'done';
    } else if (this.gameState === 'ready') {
      this.endTime = performance.now();
      this.reactionTime = +(this.endTime - this.startTime).toFixed(3);
      this.message = `⏱ Reaction Time: ${this.reactionTime} ms`;
      this.gameState = 'done';

      // Update fastest time
      if (this.fastestTime === null || this.reactionTime < this.fastestTime) {
        this.fastestTime = this.reactionTime;
      }
    }
  }

  reset() {
    this.message = 'Click "Start" to begin!';
    this.reactionTime = 0;
    this.startTime = 0;
    this.endTime = 0;
    this.gameState = 'idle';
  }

  playAgain() {
  this.resetGame();
  this.showPrompt = false;
  this.startSimulation();
}
  startSimulation() {
    throw new Error('Method not implemented.');
  }

retry() {
  this.resetGame();
}
  resetGame() {
    throw new Error('Method not implemented.');
  }

backToMenu() {
  // Redirect to main menu route
  window.location.href = '/'; // or use Angular router if available
}

}
