import { Component } from '@angular/core';

@Component({
  selector: 'app-game-view',
  templateUrl: './game-view.component.html',
  styleUrls: ['./game-view.component.css'] // ✅ Corrected from `styleUrl` to `styleUrls`
})
export class GameViewComponent {
speed: any;
gameOver: any;
confirmReady() {
throw new Error('Method not implemented.');
}
  currentIndex = -1;
  numberSequence: number[] = [];
  displayNumber: number | null = null;
  userInput: string = '';
  gameStarted = false;
  inputPhase = false;
  resultShown = false;
  success = false;
  showPrompt: boolean | undefined;

  startGame() {
    this.resetGame();
    this.gameStarted = true;

    // Generate 5 random single-digit numbers
    for (let i = 0; i < 5; i++) {
      this.numberSequence.push(Math.floor(Math.random() * 10));
    }

    // Show the numbers briefly one by one
    this.showNextNumber(0);
  }

  showNextNumber(index: number) {
    if (index >= this.numberSequence.length) {
      this.displayNumber = null;

      // After showing all numbers, allow input
      this.inputPhase = true;
      return;
    }

    // Display current number
    this.displayNumber = this.numberSequence[index];

    // Hide the number after 0.5s, then wait 0.2s before showing next
    setTimeout(() => {
      this.displayNumber = null;
      setTimeout(() => this.showNextNumber(index + 1), 200);
    }, 500);
  }

  submitGuess() {
    const entered = this.userInput.split('').map(Number);
    this.success = JSON.stringify(entered) === JSON.stringify(this.numberSequence);
    this.resultShown = true;
    this.inputPhase = false;
  }

  retryGame() {
    this.resetGame();
    this.startGame(); // Start again immediately
  }

  resetGame() {
    this.currentIndex = -1;
    this.numberSequence = [];
    this.displayNumber = null;
    this.userInput = '';
    this.gameStarted = false;
    this.inputPhase = false;
    this.resultShown = false;
    this.success = false;
  }

  playAgain() {
  this.resetGame();
  this.showPrompt = false;
  this.startSimulation();
}
  startSimulation() {
    throw new Error('Method not implemented.');
  }

retry() {
  this.resetGame();
}

backToMenu() {
  // Redirect to main menu route
  window.location.href = '/'; // or use Angular router if available
}

}
