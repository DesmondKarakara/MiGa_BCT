import { Component } from '@angular/core';

@Component({
  selector: 'app-game-view',
  templateUrl: './game-view.component.html',
  styleUrl: './game-view.component.css'
})
export class GameViewComponent {
playAgain() {
throw new Error('Method not implemented.');
}
retry() {
throw new Error('Method not implemented.');
}
speed: any;
confirmReady() {
throw new Error('Method not implemented.');
}
showPrompt: any;
gameOver: any;
backToMenu() {
throw new Error('Method not implemented.');
}
  choices = ['Rock', 'Paper', 'Scissors'];
  images: { [key: string]: string } = {
    'Rock': 'rock.jpg',
    'Paper': 'paper.webp',
    'Scissors': 'scissor.webp'
  };

  playerChoice = '';
  computerChoice = '';
  result = '';
  countdown = 3;
  showResult = false;
  isCounting = false;

  play(choice: string) {
    this.playerChoice = choice;
    this.computerChoice = '';
    this.result = '';
    this.countdown = 3;
    this.showResult = false;
    this.isCounting = true;

    const interval = setInterval(() => {
      this.countdown--;
      if (this.countdown === 0) {
        clearInterval(interval);
        this.revealComputerChoice();
      }
    }, 1000);
  }

  revealComputerChoice() {
    const randomIndex = Math.floor(Math.random() * 3);
    this.computerChoice = this.choices[randomIndex];

    setTimeout(() => {
      this.calculateResult();
      this.showResult = true;
      this.isCounting = false;
    }, 1000); // Slight delay for better user feel
  }

  calculateResult() {
    if (this.playerChoice === this.computerChoice) {
      this.result = "It's a draw!";
    } else if (
      (this.playerChoice === 'Rock' && this.computerChoice === 'Scissors') ||
      (this.playerChoice === 'Paper' && this.computerChoice === 'Rock') ||
      (this.playerChoice === 'Scissors' && this.computerChoice === 'Paper')
    ) {
      this.result = '🎉 You Win!';
    } else {
      this.result = '😔 Computer Wins!';
    }
  }

  


}
