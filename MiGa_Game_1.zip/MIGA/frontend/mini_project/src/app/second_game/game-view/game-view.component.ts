import { Component, OnInit, OnDestroy } from '@angular/core';

@Component({
  selector: 'app-game-view',
  templateUrl: './game-view.component.html',
  styleUrls: ['./game-view.component.css']
})
export class GameViewComponent implements OnInit, OnDestroy {
confirmReady() {
throw new Error('Method not implemented.');
}
  // Game state
  score = 0;
  timeLeft = 20;
  countdown = 3;
  gameStarted = false;
  isCountingDown = false;
  moleActive = false;
  moleIndex = -1;
  showHit = false;
  showEndScreen = false;
  showCongrats = false;

  // 9 fixed hole placeholders
  molePositions = Array(9).fill(0);

  private countdownTimer: any;
  private gameTimer: any;
  private moleTimer: any;
  showPrompt: boolean | undefined;
speed: any;
gameOver: any;

  ngOnInit(): void {}

  startGame() {
    this.resetState();
    // Extra 1s delay before showing countdown
    setTimeout(() => {
      this.isCountingDown = true;
      this.countdown = 3;
      this.countdownTimer = setInterval(() => {
        this.countdown--;
        if (this.countdown === 0) {
          clearInterval(this.countdownTimer);
          this.isCountingDown = false;
          this.beginGame();
        }
      }, 1000);
    }, 1000);
  }

  resetState() {
    clearInterval(this.countdownTimer);
    clearInterval(this.gameTimer);
    clearInterval(this.moleTimer);
    this.score = 0;
    this.timeLeft = 20;
    this.gameStarted = false;
    this.isCountingDown = false;
    this.moleActive = false;
    this.moleIndex = -1;
    this.showHit = false;
    this.showEndScreen = false;
    this.showCongrats = false;
  }

  beginGame() {
    this.gameStarted = true;
    // Main game timer (20s)
    this.gameTimer = setInterval(() => {
      this.timeLeft--;
      if (this.timeLeft <= 0) this.endGame();
    }, 1000);

    // Spawn mole immediately & every 1.8s
    this.spawnOneMole();
    this.moleTimer = setInterval(() => this.spawnOneMole(), 1800);
  }

  spawnOneMole() {
    this.moleActive = true;
    this.moleIndex = Math.floor(Math.random() * 9);
    // Hide mole after 1.3s
    setTimeout(() => this.moleActive = false, 1400);
  }

  hitMole(idx: number) {
    if (this.gameStarted && this.moleActive && this.moleIndex === idx) {
      this.score += 10;
      this.showHit = true;
      this.moleActive = false;
      // Hit image for 0.5s
      setTimeout(() => this.showHit = false, 400);
    }
  }

  endGame() {
    clearInterval(this.gameTimer);
    clearInterval(this.moleTimer);
    this.gameStarted = false;
    this.showEndScreen = true;
    this.showCongrats = this.score >= 100;
  }

  retryGame() {
    this.startGame();
  }

  ngOnDestroy() {
    clearInterval(this.countdownTimer);
    clearInterval(this.gameTimer);
    clearInterval(this.moleTimer);
  }

  playAgain() {
  this.resetGame();
  this.showPrompt = false;
  this.startSimulation();
}
  startSimulation() {
    throw new Error('Method not implemented.');
  }
  resetGame() {
    throw new Error('Method not implemented.');
  }

retry() {
  this.resetGame();
}

backToMenu() {
  // Redirect to main menu route
  window.location.href = '/'; // or use Angular router if available
}

}
