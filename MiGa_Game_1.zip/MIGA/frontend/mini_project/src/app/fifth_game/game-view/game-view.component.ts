import { Component, HostListener, OnInit, OnDestroy } from '@angular/core';

type SignalColor = 'red' | 'yellow' | 'green';
type VehicleType = 'car' | 'truck' | 'bus';
type Direction = 'north' | 'south' | 'east' | 'west';

interface Vehicle {
  id: string;
  type: VehicleType;
  direction: Direction;
  position: { x: number; y: number };
  speed: number;
  color: string;
  crossed: boolean;
}

interface TrafficLight {
  north: SignalColor;
  south: SignalColor;
  east: SignalColor;
  west: SignalColor;
}

interface GameObjective {
  title: string;
  description: string;
  winCondition: string;
  failCondition: string;
  controls: { key: string; action: string }[];
  tips: string[];
  scoring?: string[];
}

@Component({
  selector: 'app-game-view',
  templateUrl: './game-view.component.html',
  styleUrls: ['./game-view.component.css']
})
export class GameViewComponent implements OnInit, OnDestroy {
  // Traffic lights for intersection
  trafficLights: TrafficLight = {
    north: 'red',
    south: 'red',
    east: 'green',
    west: 'green'
  };

  // Game state
  isRunning = false;
  isPaused = false;
  simulationSpeed = 1;
  score = 0;
  accidents = 0;
  round = 1;
  maxRounds = 20;
  comboCount = 0;
  vehiclesCrossed = 0;
  
  // Vehicles
  vehicles: Vehicle[] = [];
  nextVehicleId = 1;
  
  // Game mechanics
  showPrompt = true;
  gameOver = false;
  instruction = '🚦 Ready to manage traffic intersection?';
  actionMessage = '';
  showInstructions = false;
  
  // Objective tracking
  objectiveMet = false;
  
  // Intervals
  private gameInterval: any;
  private spawnInterval: any;
  private lightChangeInterval: any;
  
  // Audio context for beeps
  private audioContext: AudioContext | null = null;
  soundEnabled = true;

  gameObjective: GameObjective = {
    title: 'Traffic Intersection Manager',
    description: 'Manage a busy traffic intersection by controlling traffic lights to ensure safe vehicle flow while maximizing efficiency.',
    winCondition: 'Score 500+ points with fewer than 5 accidents in 20 rounds',
    failCondition: 'Get 5 or more accidents, or score below 300 points',
    controls: [
      { key: 'W', action: 'Control North traffic light' },
      { key: 'A', action: 'Control West traffic light' },
      { key: 'S', action: 'Control South traffic light' },
      { key: 'D', action: 'Control East traffic light' },
      { key: '+/-', action: 'Increase/Decrease simulation speed' },
      { key: 'Space', action: 'Pause/Resume simulation' },
      { key: 'R', action: 'Reset game' }
    ],
    tips: [
      'Green lights allow vehicles to pass, red lights stop them',
      'Yellow lights warn vehicles to slow down',
      'Prevent collisions by managing traffic flow carefully',
      'Build combos by timing lights perfectly for approaching vehicles',
      'Higher simulation speeds increase difficulty but also potential points',
      'Watch for rush hour rounds (every 5th round) for bonus multipliers'
    ],
    scoring: [
      '+50 points for each round completed without accidents',
      '+10 points for each vehicle safely crossed',
      '+100 bonus for perfect combo',
      '-100 points for each accident',
      'Reach 500+ points with <5 accidents to win'
    ]
  };

  ngOnInit() {
    this.resetGame();
    this.initAudio();
  }

  ngOnDestroy() {
    this.stopGame();
  }

  showInstructionManual() {
    this.showInstructions = true;
  }

  closeInstructions() {
    this.showInstructions = false;
  }

  initAudio() {
    try {
      this.audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    } catch (e) {
      console.log('Audio not supported');
    }
  }

  playBeep(frequency: number = 800, duration: number = 200) {
    if (!this.audioContext || !this.soundEnabled) return;
    
    const oscillator = this.audioContext.createOscillator();
    const gainNode = this.audioContext.createGain();
    
    oscillator.connect(gainNode);
    gainNode.connect(this.audioContext.destination);
    
    oscillator.frequency.value = frequency;
    oscillator.type = 'sine';
    
    gainNode.gain.setValueAtTime(0.3, this.audioContext.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, this.audioContext.currentTime + duration / 1000);
    
    oscillator.start(this.audioContext.currentTime);
    oscillator.stop(this.audioContext.currentTime + duration / 1000);
  }

  @HostListener('window:keydown', ['$event'])
  onKeyDown(event: KeyboardEvent) {
    if (this.showPrompt || this.gameOver) return;
    
    const key = event.key.toLowerCase();
    event.preventDefault();

    // Traffic light controls
    if (key === 'w') {
      this.toggleLight('north');
    } else if (key === 'a') {
      this.toggleLight('west');
    } else if (key === 's') {
      this.toggleLight('south');
    } else if (key === 'd') {
      this.toggleLight('east');
    }
    // Speed controls
    else if (key === '+' || key === '=') {
      this.changeSpeed(1);
    } else if (key === '-') {
      this.changeSpeed(-1);
    }
    // Game controls
    else if (key === ' ') {
      this.togglePause();
    } else if (key === 'r') {
      this.resetGame();
    }
  }

  toggleLight(direction: Direction) {
    const currentColor = this.trafficLights[direction];
    let newColor: SignalColor;
    
    switch (currentColor) {
      case 'red':
        newColor = 'green';
        break;
      case 'green':
        newColor = 'yellow';
        break;
      case 'yellow':
        newColor = 'red';
        break;
    }
    
    this.trafficLights[direction] = newColor;
    this.playBeep(600, 150);
    this.actionMessage = `${direction.toUpperCase()} light: ${newColor.toUpperCase()}`;
    
    // Check for perfect timing bonus
    this.checkPerfectTiming(direction);
  }

  changeSpeed(delta: number) {
    this.simulationSpeed = Math.max(0.5, Math.min(3, this.simulationSpeed + delta * 0.5));
    this.playBeep(400, 100);
    this.actionMessage = `Speed: ${this.simulationSpeed.toFixed(1)}x`;
  }

  togglePause() {
    this.isPaused = !this.isPaused;
    this.playBeep(this.isPaused ? 300 : 500, 200);
    this.actionMessage = this.isPaused ? 'PAUSED' : 'RESUMED';
  }

  confirmReady() {
    this.showPrompt = false;
    this.instruction = '🚦 Traffic simulation starting...';
    setTimeout(() => this.startGame(), 1500);
  }

  startGame() {
    this.isRunning = true;
    this.isPaused = false;
    this.instruction = 'Control traffic lights: W/A/S/D | Speed: +/- | Pause: Space | Reset: R';
    
    // Start game loop
    this.gameInterval = setInterval(() => {
      if (!this.isPaused) {
        this.updateGame();
      }
    }, 50 / this.simulationSpeed);
    
    // Start spawning vehicles
    this.spawnInterval = setInterval(() => {
      if (!this.isPaused) {
        this.spawnVehicle();
      }
    }, Math.max(1000, 3000 - (this.round * 100)) / this.simulationSpeed);
  }

  stopGame() {
    this.isRunning = false;
    clearInterval(this.gameInterval);
    clearInterval(this.spawnInterval);
    clearInterval(this.lightChangeInterval);
  }

  updateGame() {
    if (this.round > this.maxRounds) {
      this.endGame();
      return;
    }

    // Move vehicles
    this.vehicles.forEach(vehicle => {
      this.moveVehicle(vehicle);
    });
    
    // Check collisions
    this.checkCollisions();
    
    // Remove vehicles that have crossed
    this.vehicles = this.vehicles.filter(vehicle => {
      if (vehicle.crossed && !this.hasVehicleCrossedBoundary(vehicle)) {
        this.score += 10;
        this.vehiclesCrossed++;
        this.comboCount++;
        if (this.comboCount >= 5) {
          this.score += 5 * this.comboCount;
          this.playBeep(800, 300);
        }
        return false;
      }
      return this.isVehicleInBounds(vehicle);
    });
    
    // Check round progression
    if (this.vehicles.length === 0 && this.round >= this.maxRounds) {
      this.endGame();
    }

    // Check objectives
    this.checkObjectives();
  }

  checkObjectives() {
    // Check fail conditions
    if (this.accidents >= 5) {
      this.objectiveMet = false;
      this.endGame();
      return;
    }

    // Check win conditions at end of game
    if (this.round > this.maxRounds) {
      if (this.score >= 500 && this.accidents < 5) {
        this.objectiveMet = true;
      } else {
        this.objectiveMet = false;
      }
      this.endGame();
    }
  }

  shouldShowPlayAgain(): boolean {
    return this.gameOver && this.objectiveMet;
  }

  shouldShowRetry(): boolean {
    return this.gameOver && !this.objectiveMet;
  }

  getGameStatus(): string {
    if (!this.gameOver) {
      return `Round ${this.round}/${this.maxRounds} | Score: ${this.score} | Accidents: ${this.accidents}`;
    }
    if (this.objectiveMet) {
      return '🏆 Objective Complete! Excellent traffic management!';
    } else {
      return '❌ Objective Failed. Try to improve your traffic management skills!';
    }
  }

  spawnVehicle() {
    const directions: Direction[] = ['north', 'south', 'east', 'west'];
    const types: VehicleType[] = ['car', 'truck', 'bus'];
    const colors = ['#ff4444', '#44ff44', '#4444ff', '#ffff44', '#ff44ff', '#44ffff'];
    
    const direction = directions[Math.floor(Math.random() * directions.length)];
    const type = types[Math.floor(Math.random() * types.length)];
    const color = colors[Math.floor(Math.random() * colors.length)];
    
    const vehicle: Vehicle = {
      id: `vehicle-${this.nextVehicleId++}`,
      type,
      direction,
      position: this.getSpawnPosition(direction),
      speed: this.getVehicleSpeed(type),
      color,
      crossed: false
    };
    
    this.vehicles.push(vehicle);
  }

  getSpawnPosition(direction: Direction): { x: number; y: number } {
    switch (direction) {
      case 'north': return { x: 200, y: 400 };
      case 'south': return { x: 200, y: 0 };
      case 'east': return { x: 0, y: 200 };
      case 'west': return { x: 400, y: 200 };
    }
  }

  getVehicleSpeed(type: VehicleType): number {
    switch (type) {
      case 'car': return 2;
      case 'truck': return 1.5;
      case 'bus': return 1;
    }
  }

  moveVehicle(vehicle: Vehicle) {
    const light = this.trafficLights[vehicle.direction];
    const shouldStop = this.shouldVehicleStop(vehicle, light);
    
    if (!shouldStop) {
      switch (vehicle.direction) {
        case 'north':
          vehicle.position.y -= vehicle.speed * this.simulationSpeed;
          break;
        case 'south':
          vehicle.position.y += vehicle.speed * this.simulationSpeed;
          break;
        case 'east':
          vehicle.position.x += vehicle.speed * this.simulationSpeed;
          break;
        case 'west':
          vehicle.position.x -= vehicle.speed * this.simulationSpeed;
          break;
      }
      
      if (this.isInIntersection(vehicle) && !vehicle.crossed) {
        vehicle.crossed = true;
      }
    }
  }

  shouldVehicleStop(vehicle: Vehicle, light: SignalColor): boolean {
    if (light === 'green') return false;
    if (light === 'red' && this.isApproachingIntersection(vehicle)) return true;
    if (light === 'yellow' && this.isCloseToIntersection(vehicle)) return true;
    return false;
  }

  isApproachingIntersection(vehicle: Vehicle): boolean {
    const threshold = 50;
    switch (vehicle.direction) {
      case 'north': return vehicle.position.y > 250 && vehicle.position.y < 250 + threshold;
      case 'south': return vehicle.position.y < 150 && vehicle.position.y > 150 - threshold;
      case 'east': return vehicle.position.x < 150 && vehicle.position.x > 150 - threshold;
      case 'west': return vehicle.position.x > 250 && vehicle.position.x < 250 + threshold;
    }
  }

  isCloseToIntersection(vehicle: Vehicle): boolean {
    const threshold = 30;
    switch (vehicle.direction) {
      case 'north': return vehicle.position.y > 250 && vehicle.position.y < 250 + threshold;
      case 'south': return vehicle.position.y < 150 && vehicle.position.y > 150 - threshold;
      case 'east': return vehicle.position.x < 150 && vehicle.position.x > 150 - threshold;
      case 'west': return vehicle.position.x > 250 && vehicle.position.x < 250 + threshold;
    }
  }

  isInIntersection(vehicle: Vehicle): boolean {
    return vehicle.position.x >= 150 && vehicle.position.x <= 250 &&
           vehicle.position.y >= 150 && vehicle.position.y <= 250;
  }

  isVehicleInBounds(vehicle: Vehicle): boolean {
    return vehicle.position.x >= -50 && vehicle.position.x <= 450 &&
           vehicle.position.y >= -50 && vehicle.position.y <= 450;
  }

  hasVehicleCrossedBoundary(vehicle: Vehicle): boolean {
    switch (vehicle.direction) {
      case 'north': return vehicle.position.y < -30;
      case 'south': return vehicle.position.y > 430;
      case 'east': return vehicle.position.x > 430;
      case 'west': return vehicle.position.x < -30;
    }
  }

  checkCollisions() {
    for (let i = 0; i < this.vehicles.length; i++) {
      for (let j = i + 1; j < this.vehicles.length; j++) {
        if (this.areVehiclesColliding(this.vehicles[i], this.vehicles[j])) {
          this.handleCollision(this.vehicles[i], this.vehicles[j]);
        }
      }
    }
  }

  areVehiclesColliding(v1: Vehicle, v2: Vehicle): boolean {
    const distance = Math.sqrt(
      Math.pow(v1.position.x - v2.position.x, 2) + 
      Math.pow(v1.position.y - v2.position.y, 2)
    );
    return distance < 25;
  }

  handleCollision(v1: Vehicle, v2: Vehicle) {
    this.accidents++;
    this.score = Math.max(0, this.score - 20);
    this.comboCount = 0;
    this.playBeep(200, 500);
    this.actionMessage = `💥 COLLISION! -20 points`;
    
    // Remove collided vehicles
    this.vehicles = this.vehicles.filter(v => v.id !== v1.id && v.id !== v2.id);
  }

  checkPerfectTiming(direction: Direction) {
    const vehiclesInDirection = this.vehicles.filter(v => 
      v.direction === direction && this.isApproachingIntersection(v)
    );
    
    if (vehiclesInDirection.length > 0 && this.trafficLights[direction] === 'green') {
      this.comboCount++;
      this.score += 5;
    }
  }


  resetGame() {
    this.stopGame();
    this.trafficLights = {
      north: 'red',
      south: 'red',
      east: 'green',
      west: 'green'
    };
    this.isRunning = false;
    this.isPaused = false;
    this.simulationSpeed = 1;
    this.score = 0;
    this.accidents = 0;
    this.round = 1;
    this.comboCount = 0;
    this.vehicles = [];
    this.nextVehicleId = 1;
    this.showPrompt = true;
    this.gameOver = false;
    this.instruction = '🚦 Ready to manage traffic intersection?';
    this.actionMessage = '';
  }

  endGame() {
    this.stopGame();
    this.gameOver = true;
    this.instruction = '🏁 Traffic Management Complete!';
    this.actionMessage = `Final Score: ${this.score} | Accidents: ${this.accidents}`;
    this.playBeep(600, 1000);
  }

  playAgain() {
    this.resetGame();
    this.showPrompt = false;
    this.startGame();
  }

  retry() {
    this.resetGame();
  }

  // Utility methods for template
  getTrafficLightIcon(direction: Direction): string {
    const color = this.trafficLights[direction];
    switch (color) {
      case 'green': return '🟢';
      case 'yellow': return '🟡';
      case 'red': return '🔴';
    }
  }

  getTrafficLightClass(direction: Direction): string {
    const color = this.trafficLights[direction];
    return `traffic-light ${direction} ${color}`;
  }

  getVehicleIcon(type: VehicleType): string {
    switch (type) {
      case 'car': return '🚗';
      case 'truck': return '🚛';
      case 'bus': return '🚌';
    }
  }

  getVehicleStyle(vehicle: Vehicle): any {
    return {
      position: 'absolute',
      left: vehicle.position.x + 'px',
      top: vehicle.position.y + 'px',
      color: vehicle.color,
      fontSize: '20px',
      transition: 'all 0.1s linear',
      zIndex: 10
    };
  }

  toggleSound() {
    this.soundEnabled = !this.soundEnabled;
    this.actionMessage = `Sound ${this.soundEnabled ? 'ON' : 'OFF'}`;
  }

  getRushHourMultiplier(): number {
    return this.round % 5 === 0 ? 2 : 1;
  }

  getScoreWithMultiplier(): number {
    return this.score * this.getRushHourMultiplier();
  }

  backToMenu() {
    // Redirect to main menu route
    window.location.href = '/';
  }
}
