import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MainMenuComponent } from './main-menu/main-menu.component';

const routes: Routes = [
  { path: '', component: MainMenuComponent },
  { path: 'menu', component: MainMenuComponent },
  { 
    path: 'rps', 
    loadChildren: () => import('./first_game/game.module').then(m => m.GameModule) 
  },
  { 
    path: 'mole', 
    loadChildren: () => import('./second_game/game.module').then(m => m.GameModule) 
  },
  { 
    path: 'GN', 
    loadChildren: () => import('./third_game/game.module').then(m => m.GameModule) 
  },
  { 
    path: 'RT', 
    loadChildren: () => import('./fourth_game/game.module').then(m => m.GameModule) 
  },
  { 
    path: 'TS', 
    loadChildren: () => import('./fifth_game/game.module').then(m => m.GameModule) 
  },
  { path: '**', redirectTo: '' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
